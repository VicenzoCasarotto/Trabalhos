function printLetterByLetter(destination, message, speed){
    var i = 0;
    var interval = setInterval(function(){
        document.getElementById(destination).innerHTML += message.charAt(i);
        i++;
        if (i > message.length){
            clearInterval(interval);
        }
    }, speed);
}

printLetterByLetter("titulo", "Festas do Vicenzo", 100);

function executeCarousel(){
    let inputs = document.querySelectorAll('input[type="radio"]')
    console.log('sexo');
    
    for (let index = 0; index < inputs.length; index++) {
        console.log(index);
        if(inputs[index].checked === true){
            inputs[index].checked = false;
            if(index === 3){
                inputs[0].checked = true;
            }
            else{
                inputs[index + 1].checked = true;
            }
            break
        }
        
    }
}

setInterval(executeCarousel, 2000)

