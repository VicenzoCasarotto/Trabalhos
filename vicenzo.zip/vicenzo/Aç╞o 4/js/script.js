function printLetterByLetter(destination, message, speed){
    var i = 0;
    var interval = setInterval(function(){
        document.getElementById(destination).innerHTML += message.charAt(i);
        i++;
        if (i > message.length){
            clearInterval(interval);
        }
    }, speed);
}

printLetterByLetter("titulo", "Minhas Festas", 100);

function executeCarousel(){
    let inputs = document.querySelectorAll('input[type="radio"]')
    console.log('sexo');
    
    for (let index = 0; index < inputs.length; index++) {
        console.log(index);
        if(inputs[index].checked === true){
            inputs[index].checked = false;
            if(index === 3){
                inputs[0].checked = true;
            }
            else{
                inputs[index + 1].checked = true;
            }
            break
        }
        
    }
}

setInterval(executeCarousel, 2000)



function localStorageFunc(){
    let titulo = document.getElementById('tituloIinput').value
    let descricao = document.getElementById('descricao').value
    let festas = JSON.parse(localStorage.getItem("festas"));
    console.log(festas);

    if(festas !== null){
        let object = {
            titulo: titulo,
            descricao: descricao
        }

        festas.push(object)
        localStorage.setItem("festas", JSON.stringify(festas))
    }
    else{
        let arrayFestas = []
        let object = {
            titulo: titulo,
            descricao: descricao
        }
        arrayFestas.push(object)
        console.log(arrayFestas);
        localStorage.setItem("festas", JSON.stringify(arrayFestas))
    }
    window.location.reload()
}

function getLocalStorage(){
    let festas = JSON.parse(localStorage.getItem("festas"));
    
    for (let index = 0; index < festas.length; index++) {
        document.getElementById('container').innerHTML += `
        <div class="festa">
            <h2>Título: ${festas[index].titulo}</h2>
            <h4>Descrição: ${festas[index].descricao}</h4>
        </div>
        `
    
    }
}

setTimeout(getLocalStorage, 1000)

